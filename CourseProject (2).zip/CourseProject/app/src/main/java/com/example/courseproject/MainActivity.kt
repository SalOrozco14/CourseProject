package com.example.courseproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.core.content.ContextCompat.startActivity

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.help->{var intent= Intent(this, AboutActivity:: class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.settings->{var intent=Intent(this, SettingsActivity:: class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }else->return super.onOptionsItemSelected(item)
        }
    }

    //Go to Help screen
   public fun goAbout(view: View){
        startActivity(Intent( this, AboutActivity:: class.java))
    }

    //Go to check list screen
    public fun goCheck(view: View){
        startActivity(Intent( this, SecondActivity:: class.java))
    }

    //Go to Help screen
    public fun goReport(view: View){
        startActivity(Intent( this, ThirdActivity:: class.java))
    }
}